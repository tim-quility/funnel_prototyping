// Mock appointment API
export const fetchAppointments = async (params: any) => {
  return [];
};
