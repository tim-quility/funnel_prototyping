// Mock Workflow API
export const fetchWorkflows = async () => [];
export const bulkEnrollLeads = async () => {};
