// Mock Dialer Context
export const useDialer = () => ({
  startSession: () => {},
});
